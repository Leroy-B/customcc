#import <Preferences/PSListController.h>

@interface CCCPositionListController : PSListController

@end

static NSUserDefaults *preferences;

static NSDictionary *customPositionSettings;
static NSDictionary *positionSettings; //folderSettings
static NSString *folderName;
static NSString *folderID;

static void setSetting(id value, NSString * folderID, NSString * specifierID) {

    NSMutableDictionary *mutableCustomPositionSettings = [customPositionSettings mutableCopy];
    NSMutableDictionary *mutablePositionSettings = [positionSettings mutableCopy];
    if(!mutablePositionSettings) {
      mutablePositionSettings = [NSMutableDictionary new];
    }
    if(!mutableCustomPositionSettings) {
      mutableCustomPositionSettings = [NSMutableDictionary new];
    }


    [mutablePositionSettings setObject:value forKey:specifierID];
    [mutableCustomPositionSettings setObject:mutablePositionSettings forKey:folderID];

    preferences = [[NSUserDefaults alloc] initWithSuiteName:@"nl.jessevandervelden.swipyfoldersprefs"];
    [preferences setObject:mutableCustomPositionSettings forKey:@"customPositionSettings"];
    [preferences synchronize];


    CFStringRef toPost = (CFStringRef)@"nl.jessevandervelden.swipyfoldersprefs/prefsChanged"; //(CFStringRef)specifier.properties[@"PostNotification"];
    if(toPost) {
      CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), toPost, NULL, NULL, YES);
    }

    customFolderSettings = [mutableCustomFolderSettings copy];
    folderSettings = [mutableFolderSettings copy];

}

@implementation CCCPositionListController



@end
